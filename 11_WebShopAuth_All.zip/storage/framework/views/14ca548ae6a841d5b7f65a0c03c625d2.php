<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Upravljanje korisnicima
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
            <?php if(session('success')): ?>

        <div
            class="mb-4
                p-4
                bg-green-100
                text-green-700
                rounded"
        >
            <?php echo e(session('success')); ?>

        </div>

    <?php endif; ?>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">

                    <h3 class="text-lg font-semibold mb-4">
                        Popis korisnika
                    </h3>

                    <div class="admin-table-wrapper">
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Ime</th>
                                    <th>Email</th>
                                    <th>Admin</th>
                                    <th>Datum rođenja</th>
                                    <th>Plaća</th>
                                    <th>Akcije</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>

                                        <td>
                                            <?php if($user->isAdmin): ?>
                                                <span class="badge-admin">
                                                    DA
                                                </span>
                                            <?php else: ?>
                                                <span class="badge-user">
                                                    NE
                                                </span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <?php echo e($user->datum_rod?->format('d.m.Y.')); ?>

                                        </td>

                                        <td>
                                            <?php echo e(number_format($user->placa, 2, ',', '.')); ?> €
                                        </td>
                                        <td>
                                        <div class="action-buttons">

                                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                                            class="icon-button icon-edit"
                                            title="Uredi">

                                                <i class="bi bi-pencil-square"></i>

                                            </a>

                                            <a href="<?php echo e(route('admin.users.deletePreview', $user)); ?>"
                                                class="icon-button icon-delete"
                                                title="Obriši">

                                                    <i class="bi bi-trash"></i>

                                                </a>

                                        </div>

                                    </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\www\personal\LARAVEL\11_WebShopAuth_All\resources\views/admin/users/index.blade.php ENDPATH**/ ?>