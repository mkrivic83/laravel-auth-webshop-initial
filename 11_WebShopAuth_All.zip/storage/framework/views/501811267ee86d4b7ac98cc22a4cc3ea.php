<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Detalji proizvoda
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow-sm sm:rounded-lg">
                <div class="p-6">

                    <table class="admin-table">
                        <tr>
                            <th>ID</th>
                            <td><?php echo e($product->id); ?></td>
                        </tr>

                        <tr>
                            <th>Naziv</th>
                            <td><?php echo e($product->naziv); ?></td>
                        </tr>

                        <tr>
                            <th>Kategorija</th>
                            <td><?php echo e($product->category->naziv); ?></td>
                        </tr>

                        <tr>
                            <th>Opis</th>
                            <td><?php echo e($product->opis); ?></td>
                        </tr>

                        <tr>
                            <th>Cijena</th>
                            <td>
                                <?php echo e(number_format($product->cijena, 2, ',', '.')); ?> €
                            </td>
                        </tr>

                        <tr>
                            <th>Količina</th>
                            <td><?php echo e($product->kolicina); ?></td>
                        </tr>
                        <tr>
                            <th>Izvor</th>
                            <td><?php echo e($product->izvor); ?></td>
                        </tr>
                        <tr>
                            <th>Kreirano</th>
                            <td><?php echo e($product->created_at?->format('d.m.Y. H:i')); ?></td>
                        </tr>

                        <tr>
                            <th>Ažurirano</th>
                            <td><?php echo e($product->updated_at?->format('d.m.Y. H:i')); ?></td>
                        </tr>
                    </table>

                    <div class="mt-6 flex gap-3">
                        <a
                            href="<?php echo e(route('products.index')); ?>"
                            class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                        >
                            Povratak
                        </a>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-access')): ?>
                            <a
                                href="<?php echo e(route('products.edit', $product)); ?>"
                                class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                            >
                                Uredi
                            </a>
                        <?php endif; ?>
                    </div>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\www\personal\LARAVEL\11_WebShopAuth_All\resources\views/products/show.blade.php ENDPATH**/ ?>