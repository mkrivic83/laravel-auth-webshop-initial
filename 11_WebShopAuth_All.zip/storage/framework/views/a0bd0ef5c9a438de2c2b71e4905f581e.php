<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl">
            Sumarni prikaz kategorija
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <div class="bg-white shadow-sm sm:rounded-lg">

                <div class="p-6">

                    <h3 class="text-lg font-semibold mb-4">

                        Statistika proizvoda po kategorijama

                    </h3>

                    <div class="admin-table-wrapper">

                        <table class="admin-table">

                            <thead>

                                <tr>

                                    <th>ID</th>

                                    <th>Kategorija</th>

                                    <th>Broj proizvoda</th>

                                    <th>Ukupna vrijednost (€)</th>

                                    <th>Minimalna cijena</th>

                                    <th>Maksimalna cijena</th>

                                    <th>Prosječna cijena</th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                    <tr>

                                        <td><?php echo e($category->id); ?></td>

                                        <td><?php echo e($category->naziv); ?></td>

                                        <td>

                                            <?php echo e($category->products_count); ?>


                                        </td>

                                        <td>

                                            <?php echo e(number_format($category->products_sum_cijena ?? 0,2,',','.')); ?>


                                        </td>

                                        <td>

                                            <?php echo e(number_format($category->products_min_cijena ?? 0,2,',','.')); ?>


                                        </td>

                                        <td>

                                            <?php echo e(number_format($category->products_max_cijena ?? 0,2,',','.')); ?>


                                        </td>

                                        <td>

                                            <?php echo e(number_format($category->products_avg_cijena ?? 0,2,',','.')); ?>


                                        </td>

                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <tr>

                                        <td colspan="7">

                                            Nema podataka.

                                        </td>

                                    </tr>

                                <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                    <div class="mt-6">

                        <?php echo e($categories->links()); ?>


                    </div>

                </div>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\www\personal\LARAVEL\11_WebShopAuth_All\resources\views/categories/summary.blade.php ENDPATH**/ ?>